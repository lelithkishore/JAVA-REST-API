package com.example.Elevatordemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElevatordemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
