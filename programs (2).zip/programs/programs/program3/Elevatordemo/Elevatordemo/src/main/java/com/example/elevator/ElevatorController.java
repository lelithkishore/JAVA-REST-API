package com.example.elevator;

import com.example.elevator.Elevator;
import com.example.elevator.ElevatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/elevators")
public class ElevatorController {

    @Autowired
    private ElevatorService elevatorService;

    @GetMapping
    public List<Elevator> getAllElevators() {
        return elevatorService.getAllElevators();
    }

    @GetMapping("/{id}")
    // public Elevator getElevatorById(@PathVariable Long id) {
    // return ;//elevatorService.getElevatorById(id);
    // }

    @PostMapping
    public Elevator addElevator(@RequestBody Elevator elevator) {
        return elevatorService.addElevator(elevator);
    }

    @PutMapping("/{id}")
    public Elevator updateElevator(@PathVariable Long id, @RequestBody Elevator elevator) {
        return elevatorService.updateElevator(id, elevator);
    }

    @DeleteMapping("/{id}")
    public void deleteElevator(@PathVariable Long id) {
        elevatorService.deleteElevator(id);
    }

    @PostMapping("/{id}/addStop/{floor}")
    public void addStop(@PathVariable Long id, @PathVariable int floor) {
        elevatorService.addStop(id, floor);
    }
}
