package com.example.elevator;

import com.example.elevator.repository.ElevatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ElevatorService {

    @Autowired
    private ElevatorRepository elevatorRepository;

    // Constructor
    public ElevatorService(ElevatorRepository elevatorRepository) {
        this.elevatorRepository = elevatorRepository;
    }

    // Create: Add a new elevator
    public Elevator addElevator(Elevator elevator) {
        return elevatorRepository.save(elevator);
    }

    // Read: Get all elevators
    public List<Elevator> getAllElevators() {
        return elevatorRepository.findAll();
    }

    // Read: Get elevator by id
    public Optional<Elevator> getElevatorById(Long id) {
        return elevatorRepository.findById(id);
    }

    // Update: Update elevator details
    public Elevator updateElevator(Long id, Elevator updatedElevator) {
        Optional<Elevator> existingElevator = elevatorRepository.findById(id);
        if (existingElevator.isPresent()) {
            Elevator elevator = existingElevator.get();
            elevator.setCurrentFloor(updatedElevator.getCurrentFloor());
            // Update other properties as needed
            return elevatorRepository.save(elevator);
        } else {
            // Handle not found scenario
            return null;
        }
    }

    // Delete: Remove elevator by id
    public void deleteElevator(Long id) {
        elevatorRepository.deleteById(id);
    }

    // Additional Method: Add a stop to the elevator's list of stops
    public void addStop(Long id, int floor) {
        Optional<Elevator> optionalElevator = elevatorRepository.findById(id);
        if (optionalElevator.isPresent()) {
            Elevator elevator = optionalElevator.get();
            elevator.addStop(floor);
            elevatorRepository.save(elevator);
        }
    }
}
