package com.example.elevator;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class ElevatorInfo {
    public ElevatorInfo(String string) {
        // TODO Auto-generated constructor stub
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToOne(mappedBy = "elevatorInfo")
    private Elevator elevator;

    public void setElevator(Elevator elevator2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setElevator'");
    }

    // Constructors, getters, setters, and other methods
}
