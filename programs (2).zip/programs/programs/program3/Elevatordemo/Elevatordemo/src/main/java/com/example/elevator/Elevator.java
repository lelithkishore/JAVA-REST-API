package com.example.elevator;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Elevator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int currentFloor;

    @OneToOne
    private ElevatorInfo elevatorInfo;

    private List<Integer> stops;

    // Constructors
    public Elevator() {
        // Default constructor for JPA
        stops = new ArrayList<>();
    }

    public Elevator(int currentFloor) {
        this.currentFloor = currentFloor;
        stops = new ArrayList<>();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    public ElevatorInfo getElevatorInfo() {
        return elevatorInfo;
    }

    public void setElevatorInfo(ElevatorInfo elevatorInfo) {
        this.elevatorInfo = elevatorInfo;
    }

    public List<Integer> getStops() {
        return stops;
    }

    public void setStops(List<Integer> stops) {
        this.stops = stops;
    }

    // Additional methods
    /**
     * @param floor
     */
    public void addStop(int floor) {
        if (floor >= 0 && floor <= 10) {
            stops.add(floor);
            stops.sort(Integer::compareTo);
        } else {
            System.out.println("Invalid floor requested: " + floor);
        }
    }

    public void move() {
        if (stops.isEmpty()) {
            // Handle case when there are no stops
            return;
        }

        int nextFloor = stops.get(0);
        if (nextFloor > currentFloor) {
            currentFloor++;
        } else if (nextFloor < currentFloor) {
            currentFloor--;
        } else {
            stops.remove(0);
            System.out.println("Elevator reached floor " + currentFloor);
            // Open doors, wait, close doors
        }
    }

    @Override
    public String toString() {
        return "Elevator{" +
                "id=" + id +
                ", currentFloor=" + currentFloor +
                ", elevatorInfo=" + elevatorInfo +
                ", stops=" + stops +
                '}';
    }
}
