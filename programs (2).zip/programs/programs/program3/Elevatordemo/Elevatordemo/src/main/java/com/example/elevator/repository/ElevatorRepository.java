package com.example.elevator.repository;

import com.example.elevator.Elevator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ElevatorRepository extends JpaRepository<Elevator, Long> {
    List<Elevator> findAllByCurrentFloorGreaterThan(int floor);

    Elevator findTopByOrderByCurrentFloorDesc();

    List<Elevator> findAllByDirection(ElevatorDirection direction);
}
