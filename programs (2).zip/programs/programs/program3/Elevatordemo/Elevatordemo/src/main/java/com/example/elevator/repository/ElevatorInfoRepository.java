package com.example.elevator.repository;

import com.example.elevator.Elevator;
import com.example.elevator.ElevatorInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ElevatorInfoRepository extends JpaRepository<ElevatorInfo, Long> {
    ElevatorInfo findByName(String name);

    List<ElevatorInfo> findAllByNameContains(String keyword);

    ElevatorInfo findByElevator(Elevator elevator);
}
