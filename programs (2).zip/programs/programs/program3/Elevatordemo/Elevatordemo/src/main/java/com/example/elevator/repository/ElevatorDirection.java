package com.example.elevator.repository;

public enum ElevatorDirection {
    UP, DOWN, IDLE
}
